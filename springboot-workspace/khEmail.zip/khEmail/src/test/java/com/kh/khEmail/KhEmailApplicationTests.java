package com.kh.khEmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
