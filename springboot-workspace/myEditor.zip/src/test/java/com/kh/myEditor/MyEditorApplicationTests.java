package com.kh.myEditor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyEditorApplicationTests {

	@Test
	void contextLoads() {
	}

}
