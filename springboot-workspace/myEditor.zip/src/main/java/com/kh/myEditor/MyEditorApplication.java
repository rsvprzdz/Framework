package com.kh.myEditor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEditorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEditorApplication.class, args);
	}

}
