package com.kh.myEditor.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kh.myEditor.model.service.BoardService;
import com.kh.myEditor.model.vo.Board;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequiredArgsConstructor
public class BoardController {
	private final BoardService bService; 
	
	@GetMapping("/board")
	public String enrollBoard() {
		return "/board/enrollBoard";
	}
	
	// 리스폰스 바디를 붙였다: 비동기통신을 하겠다. 리턴ok를 한다: 리스폰스바디를 붙여야함
	@ResponseBody
	@PostMapping("/board")
	public String insertBoard(@RequestBody Board board) {
		log.info("data --> {}", board);
		int result = bService.insertBoard(board);
		
		return result > 0 ? "ok" : "fail";
	}
}
