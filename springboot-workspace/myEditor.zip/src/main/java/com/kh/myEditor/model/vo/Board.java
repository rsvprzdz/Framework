package com.kh.myEditor.model.vo;

import lombok.Data;

@Data
public class Board {

	private String title;
	private String content;
}
